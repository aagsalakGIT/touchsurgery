import { Given, When, Then } from '@wdio/cucumber-framework';
import homepagePage from '../pageobjects/homepage.page';
import Homepage from '../pageobjects/homepage.page';
import Loginpage from '../pageobjects/loginpage.page';


Given(/^I launch reddit website/, async () => {
    await Homepage.open();
});

Given(/^I am on homepage/, async () => {
    Homepage.assertSearchTextFieldIsDisplayed();
});

When(/^I search for (.*)$/, async (searchTerm) => {
    const result = await Homepage.searchForText(searchTerm);
    expect(result).toBeTruthy();
});

When(/^I open the sub-reddit/, async () => {
    await Homepage.selectSearchResult(0);
});

When(/^I print out the top most post title/, async () => {
    const title = await Homepage.getPostTitleBasedOnSequenceNumber();
    expect(title).not.toEqual(null);
    console.log(`Post title - ${title}`);
});

Then(/^Perform Login with (\w+) and (.+)$/, async (username, password) => {
    await Loginpage.selectLoginButton();
    await Loginpage.login(username, password);
    await Loginpage.assertSuccessfulLogin();
});

Then(/^DownVote the second post if upvoted else upvote/, async () => {
    await homepagePage.downVoteIfUpVotedOtherwiseUpVoteLogic(1);
});




