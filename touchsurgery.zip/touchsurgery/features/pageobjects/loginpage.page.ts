import { ChainablePromiseElement } from 'webdriverio';
import BasePage from './basepage.page';

const waitTimeOut = 10000;

/**
 * sub page containing specific selectors and methods for a specific page
 */
class LoginPage extends BasePage {
    /**
     * define selectors using getter methods
     */
    private get inputUsernameLocator(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('input[name="username"]');
    }

    private get inputPasswordLocator(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('input[name="password"]');
    }

    private get btnSubmitLocator(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('button.AnimatedForm__submitButton.m-full-width');
    }

    private get btnLoginLocator(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('//a[text()="Log In"]');
    }

    private get userProfileLocator(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('#email-collection-tooltip-id');
    }

    private get loginFormFrameLocator(): string {
        return 'iframe._25r3t_lrPF3M6zD2YkWvZU';
    }

    /**
     * a method to encapsule automation code to interact with the page
     * e.g. to login using username and password
     */
    public async login (username: string, password: string): Promise<void> {
        await super.switchToFrame(this.loginFormFrameLocator, 10000);
        await this.inputUsernameLocator.setValue(username);
        await this.inputPasswordLocator.setValue(password);
        await this.btnSubmitLocator.click();
        await super.switchToParentFrame();
    }

    public async selectLoginButton() {
        await this.btnLoginLocator.click()
    }

    public async assertSuccessfulLogin(){
        await this.userProfileLocator.waitForDisplayed({ timeout: waitTimeOut});
        expect(await this.userProfileLocator.isDisplayed()).toBeTruthy();
    }
}

export default new LoginPage();
