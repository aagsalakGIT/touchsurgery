import { ChainablePromiseElement } from 'webdriverio';
import BasePage from './basepage.page';

const waitTimeOut = 10000;
const waitTime = 5000;

class Homepage extends BasePage {

    private get headerSearchField(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('#header-search-bar');
    }

    private get getPosts(): ChainablePromiseElement<Promise<WebdriverIO.ElementArray>> {
        return $$('div[data-testid="post-container"]')[0];
    }

    private get getPostAsList(): ChainablePromiseElement<Promise<WebdriverIO.ElementArray>> {
        return $$('div[data-testid="post-container"]');
    }

    private get searchDropDownContent(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $('#SearchDropdownContent');
    }

    private get searchResult(): ChainablePromiseElement<Promise<WebdriverIO.Element>> {
        return $$('a[role="link"]');
    }

    public async open(): Promise<string> {
        return await super.open();
    }

    public async searchForText(searchTerm: string): Promise<boolean> {
        await this.headerSearchField.waitForClickable({ timeout: waitTimeOut });
        await this.headerSearchField.setValue(searchTerm);
        await this.headerSearchField.click();
        await this.searchDropDownContent.waitForDisplayed({ timeout: waitTimeOut })
        return await this.searchDropDownContent.isDisplayed();
    }

    public async selectSearchResult(sequenceNumber: number): Promise<any> {
        await super.delay(waitTime * 2); // delay to allow search drop down load
        await this.searchDropDownContent.waitForDisplayed({ timeout: waitTimeOut });
        const searchElemText = await this.searchResult[sequenceNumber].getText();
        /**  at times sub-reddit page wihtout any content is listed first on search result.
        * logic below moves to next search result from list
        */
        if(searchElemText.includes("0 members")) sequenceNumber = sequenceNumber + 1;
        await this.searchResult[sequenceNumber].click();
    }

    public async getPostTitleBasedOnSequenceNumber(): Promise<string> {
        await super.delay(waitTime * 4); // delay to allow inconsistent page load properly
        await this.getPostAsList[1].waitForDisplayed({ timeout: waitTimeOut });
        const postElem = await this.getPostAsList[1];
        return await postElem.$('h3').getText();
    }

    public async downVoteIfUpVotedOtherwiseUpVoteLogic(postSequenceNumber: number) {
        let voteByAttrib: string;
        let post = await this.getPostAsList[postSequenceNumber];

        // if post is an advert then select next post
        if (await this.isPostAnAdvert(post)) {
            post = await this.getPostAsList[postSequenceNumber + 1];
        }

        /**  get vote if already casted
        * elementArray locator [$$] used as error occurs if element is not located using [$]
        */
        const votedElem = await post.$$('button[aria-pressed="true"]');

        // if vote casted get vote type (upvote or downvote)
        if (votedElem.length > 0) voteByAttrib = await votedElem[0].getAttribute('aria-label');

        // Logic to vote based on requirement
        await this.clickVoteButton(voteByAttrib, post);
    }

    private async clickVoteButton(voteByAttrib: string, post: any) {
        if (voteByAttrib != undefined && voteByAttrib.toLowerCase() == "upvote") {
            await post.$('button[data-click-id="downvote"]').$('i').click();
        }
        else {
            await post.$('button[data-click-id="upvote"]').$('i').click();
        }
    }

    private async isPostAnAdvert(post: WebdriverIO.Element): Promise<boolean> {
        const text = await post.$('div[data-click-id="background"]').getText();
        return (text.toLowerCase().includes("promoted"));
    }

    public async assertSearchTextFieldIsDisplayed() {
        await this.headerSearchField.isDisplayed();
    }
}

export default new Homepage();
