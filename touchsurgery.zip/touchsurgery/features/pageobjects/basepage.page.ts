/**
* main page object containing all methods, selectors and functionality
* that is shared across all page objects
*/
export default class BasePage {
    /**
    * Opens a sub page of the page
    * @param path path of the sub page (e.g. /path/to/page.html)
    */
    public open(): Promise<string> {
        return browser.url(`https://www.reddit.com`, { waitUntil: 'networkidle' });
    }

    public async delay(time: number) {
        await browser.pause(time);
    }

    public async switchToFrame(locator: string, timeout?: number){
        let time = timeout ? timeout : 5000;
        const frame = await browser.$(locator);
        await browser.pause(1000);
        await browser.switchToFrame(frame);
        await browser.setTimeout({ 'implicit': time });
    }

    public async switchToParentFrame(){
        await browser.switchToParentFrame();
    }
}
